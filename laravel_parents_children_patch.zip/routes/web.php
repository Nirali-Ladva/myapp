<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ParentController;
use App\Http\Controllers\ChildController;

Route::get('/', function(){ return redirect()->route('login'); });

Route::get('login', [AuthController::class,'showLogin'])->name('login');
Route::post('login', [AuthController::class,'login'])->name('login.post');
Route::post('logout', [AuthController::class,'logout'])->name('logout');

Route::middleware(['auth','profile.complete'])->prefix('admin')->group(function(){
    Route::get('dashboard', function(){ return view('admin.dashboard'); })->name('admin.dashboard');
    Route::get('profile/edit', [ProfileController::class,'edit'])->name('admin.profile.edit');
    Route::post('profile/update', [ProfileController::class,'update'])->name('admin.profile.update');

    Route::resource('parents', ParentController::class);
    Route::post('parents/delete-multiple', [ParentController::class,'destroy'])->name('parents.deleteMultiple');
    Route::post('parents/{parent}/delete-proof', [ParentController::class,'deleteProof'])->name('parents.deleteProof');

    Route::resource('children', ChildController::class);
    Route::post('children/delete-multiple', [ChildController::class,'destroy'])->name('children.deleteMultiple');
});
