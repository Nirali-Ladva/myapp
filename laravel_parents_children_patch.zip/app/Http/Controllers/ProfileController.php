<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class ProfileController extends Controller
{
    public function edit()
    {
        $user = Auth::user();
        return view('admin.profile.edit', compact('user'));
    }

    public function update(Request $request)
    {
        $user = Auth::user();
        $data = $request->validate([
            'first_name'=>'required|string',
            'last_name'=>'nullable|string',
            'birth_date'=>'required|date',
            'country'=>'required|string',
            'state'=>'required|string',
            'city'=>'required|string',
            'profile_image'=>'nullable|image|max:2048',
            'residential_proofs.*'=>'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
            'education'=>'nullable|string',
            'occupation'=>'nullable|string',
        ]);

        $data['age'] = Carbon::parse($data['birth_date'])->age;

        if ($request->hasFile('profile_image')) {
            $path = $request->file('profile_image')->store('profiles','public');
            $data['profile_image'] = $path;
        }

        $existing = $user->residential_proofs ?? [];
        if ($request->hasFile('residential_proofs')) {
            foreach ($request->file('residential_proofs') as $file) {
                $path = $file->store('residential_proofs','public');
                $existing[] = $path;
            }
        }
        $data['residential_proofs'] = $existing;

        $data['profile_completed'] = true;

        $user->update($data);

        return redirect()->route('admin.dashboard')->with('success','Profile updated.');
    }
}
