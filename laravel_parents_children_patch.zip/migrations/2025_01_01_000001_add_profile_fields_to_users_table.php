<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('is_admin')->default(true)->after('email');
            $table->boolean('profile_completed')->default(false)->after('is_admin');
            $table->string('first_name')->nullable()->after('profile_completed');
            $table->string('last_name')->nullable()->after('first_name');
            $table->date('birth_date')->nullable()->after('last_name');
            $table->unsignedTinyInteger('age')->nullable()->after('birth_date');
            $table->string('country')->nullable()->after('age');
            $table->string('state')->nullable()->after('country');
            $table->string('city')->nullable()->after('state');
            $table->string('profile_image')->nullable()->after('city');
            $table->json('residential_proofs')->nullable()->after('profile_image');
            $table->string('education')->nullable()->after('residential_proofs');
            $table->string('occupation')->nullable()->after('education');
        });
    }
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'is_admin','profile_completed','first_name','last_name','birth_date','age',
                'country','state','city','profile_image','residential_proofs','education','occupation'
            ]);
        });
    }
};
